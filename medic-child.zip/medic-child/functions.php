<?php

add_action( 'wp_enqueue_scripts', 'medic_child_enqueue_styles' );
function medic_child_enqueue_styles() {
 
    $parent_style = 'parent-style';
 
    wp_enqueue_style( $parent_style, get_template_directory_uri() . '/style.css', array( 'medic-bootstrap', 'medic-owl-theme-default', 'medic-owl-carousel', 'medic-magnific-popup', 'medic-animate', 'medic-boxicons', 'medic-flaticon', 'medic-meanmenu', 'medic-nice-select', 'medic-odometer', 'medic-main' ) );
    wp_enqueue_style( 'child-style',
        get_stylesheet_directory_uri() . '/style.css',
        array( $parent_style ),
        wp_get_theme()->get('Version')
    );
}
