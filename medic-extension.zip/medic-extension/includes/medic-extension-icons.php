<?php

/**
 * Add custom icon into elementor icon field
 */
function medic_extension_icons() {
    return [
        // Box Icons
        'bx bx-share-alt'           => esc_html__( 'Share Alt', 'medic-extension' ),
        'bx bxs-map'                => esc_html__( 'Map', 'medic-extension' ),
        'bx bx-cube'                => esc_html__( 'Cube', 'medic-extension' ),
        'bx bx-diamond'             => esc_html__( 'Diamond', 'medic-extension' ),
        'bx bxs-user'               => esc_html__( 'User', 'medic-extension' ),
        'bx bx-user-pin'            => esc_html__( 'User Pin', 'medic-extension' ),
        'bx bxs-user-pin'           => esc_html__( 'User Pin Alt', 'medic-extension' ),
        'bx bx-support'             => esc_html__( 'Support', 'medic-extension' ),
        'bx bx-atom'                => esc_html__( 'Atom', 'medic-extension' ),
        'bx bxs-file-doc'           => esc_html__( 'File Doc', 'medic-extension' ),
        'bx bx-anchor'              => esc_html__( 'Anchor', 'medic-extension' ),
        'bx bx-category'            => esc_html__( 'Category', 'medic-extension' ),
        'bx bxs-shapes'             => esc_html__( 'Shapes', 'medic-extension' ),
        'bx bx-message-alt-edit'    => esc_html__( 'Message Edit', 'medic-extension' ),
        'bx bx-toggle-left'         => esc_html__( 'Toggle Left', 'medic-extension' ),
        'bx bx-toggle-right'        => esc_html__( 'Toggle Right', 'medic-extension' ),
        'bx bx-news'                => esc_html__( 'News', 'medic-extension' ),
        'bx bx-box'                 => esc_html__( 'Box', 'medic-extension' ),
        'bx bx-brush-alt'           => esc_html__( 'Brush', 'medic-extension' ),
        'bx bx-extension'           => esc_html__( 'Extension', 'medic-extension' ),
        'bx bx-gift'                => esc_html__( 'Gift', 'medic-extension' ),
        'bx bx-table'               => esc_html__( 'Table', 'medic-extension' ),
        'bx bx-abacus'              => esc_html__( 'Abacus', 'medic-extension' ),
        'bx bx-group'               => esc_html__( 'Group', 'medic-extension' ),
        'bx bx-folder-plus'         => esc_html__( 'Folder', 'medic-extension' ),
        'bx bx-rocket'              => esc_html__( 'Rocket', 'medic-extension' ),
        'bx bxs-hot'                => esc_html__( 'Hot', 'medic-extension' ),
        'bx bx-download'            => esc_html__( 'Download', 'medic-extension' ),
        'bx bx-grid-alt'            => esc_html__( 'Grid', 'medic-extension' ),
        'bx bx-credit-card-front'   => esc_html__( 'Credit Card Front', 'medic-extension' ),
        'bx bx-refresh'             => esc_html__( 'Refresh', 'medic-extension' ),
        'bx bxs-truck'              => esc_html__( 'Truck', 'medic-extension' ),
        'bx bx-time-five'           => esc_html__( 'Time Five', 'medic-extension' ),
        'bx bx-phone-call'          => esc_html__( 'Phone Call', 'medic-extension' ),
        'bx bx-map'                 => esc_html__( 'Map', 'medic-extension' ),
        'bx bx-globe'               => esc_html__( 'Globe', 'medic-extension' ),
        'bx bx-plus'                => esc_html__( 'Plus', 'medic-extension' ),
        'bx bx-play'                => esc_html__( 'Play', 'medic-extension' ),
        'bx bx-chevron-right'       => esc_html__( 'Chevron Right', 'medic-extension' ),
        'bx bx-donate-blood'        => esc_html__( 'Donate Blood', 'medic-extension' ),
        'bx bxs-bank'               => esc_html__( 'Bank', 'medic-extension' ),
        'bx bx-cog'                 => esc_html__( 'Cog', 'medic-extension' ),
        'bx bx-layer'               => esc_html__( 'Layer', 'medic-extension' ),
        'bx bx-brain'               => esc_html__( 'Brain', 'medic-extension' ),
        'bx bxl-google'             => esc_html__( 'Google', 'medic-extension' ),
        'bx bxl-twitter'            => esc_html__( 'Twitter', 'medic-extension' ),
        'bx bxl-linkedin'           => esc_html__( 'Linkedin', 'medic-extension' ),
        'bx bxl-instagram'          => esc_html__( 'Instagram', 'medic-extension' ),
        'bx bxl-instagram-alt'      => esc_html__( 'Instagram Alt', 'medic-extension' ),
        'bx bxl-facebook'           => esc_html__( 'facebook', 'medic-extension' ),
        'bx bxl-pinterest-alt'      => esc_html__( 'Pinterest', 'medic-extension' ),
        'bx bxl-youtube'            => esc_html__( 'YouTube', 'medic-extension' ),
        'bx bxl-skype'              => esc_html__( 'Skype', 'medic-extension' ),
        'bx bxl-vimeo'              => esc_html__( 'Vimeo', 'medic-extension' ),
        'bx bxl-messenger'          => esc_html__( 'Messenger', 'medic-extension' ), 
        'bx bx-info-circle'         => esc_html__( 'Info Circle', 'medic-extension' ),
        'bx bx-book-open'           => esc_html__( 'Book Open', 'medic-extension' ),
        'bx bx-shopping-bag'        => esc_html__( 'Shopping', 'medic-extension' ),
        'bx bxs-badge-dollar'       => esc_html__( 'Dollar', 'medic-extension' ),
        'bx bx-copy-alt'            => esc_html__( 'Copy', 'medic-extension' ),
        'bx bx-code-alt'            => esc_html__( 'Code', 'medic-extension' ),
        'bx bx-flag'                => esc_html__( 'Flag', 'medic-extension' ),
        'bx bx-camera'              => esc_html__( 'Camera', 'medic-extension' ),
        'bx bxs-flag-checkered'     => esc_html__( 'Flag Checkered', 'medic-extension' ),
        'bx bx-health'              => esc_html__( 'Health', 'medic-extension' ),
        'bx bxs-lock-open'          => esc_html__( 'Lock Open', 'medic-extension' ),
        'bx bx-line-chart'          => esc_html__( 'Line Chart', 'medic-extension' ),
        'bx bx-book-reader'         => esc_html__( 'Book Reader', 'medic-extension' ),
        'bx bx-target-lock'         => esc_html__( 'Target Lock', 'medic-extension' ),
        'bx bxs-thermometer'        => esc_html__( 'Thermometer', 'medic-extension' ),
        'bx bx-shape-triangle'      => esc_html__( 'Triangle', 'medic-extension' ),
        'bx bx-font-family'         => esc_html__( 'Font Family', 'medic-extension' ),
        'bx bxs-drink'              => esc_html__( 'Drink', 'medic-extension' ),
        'bx bx-first-aid'           => esc_html__( 'First Aid', 'medic-extension' ),
        'bx bx-bar-chart-alt-2'     => esc_html__( 'Chart', 'medic-extension' ),
        'bx bx-briefcase-alt-2'     => esc_html__( 'Briefcase', 'medic-extension' ),
        'bx bx-book-reader'         => esc_html__( 'Book Reader', 'medic-extension' ),
        'bx bx-user-circle'         => esc_html__( 'User Circle', 'medic-extension' ),
        'bx bx-check'               => esc_html__( 'Check', 'medic-extension' ),
        'bx bx-check-circle'        => esc_html__( 'Check Circle', 'medic-extension' ),
        'bx bx-cake'                => esc_html__( 'Cake', 'medic-extension' ),
        'bx bx-paper-plane'         => esc_html__( 'Paper Plane', 'medic-extension' ),
        'bx bx-laptop'              => esc_html__( 'Laptop', 'medic-extension' ),
        'bx bx-mobile-vibration'    => esc_html__( 'Mobile Vibration', 'medic-extension' ),
        'bx bxs-paper-plane'        => esc_html__( 'Paper Plane Alt', 'medic-extension' ),
        'bx bx-file'                => esc_html__( 'File', 'medic-extension' ),
        'bx bx-user-voice'          => esc_html__( 'User Voice', 'medic-extension' ),
        'bx bxs-quote-alt-right'    => esc_html__( 'Quote Right', 'medic-extension' ),
        'bx bxs-quote-alt-left'     => esc_html__( 'Quote Left', 'medic-extension' ),
        'bx bx-chevron-down'        => esc_html__( 'Chevron Down', 'medic-extension' ),
        'bx bx-chevron-up'          => esc_html__( 'Chevron Up', 'medic-extension' ),
        'bx bxs-send'               => esc_html__( 'Send', 'medic-extension' ),
        'bx bx-right-arrow-alt'     => esc_html__( 'Right Arrow Alt', 'medic-extension' ),
        'bx bxs-phone-call'         => esc_html__( 'Phone Call 2', 'medic-extension' ),
        'bx bx-location-plus'       => esc_html__( 'Location Plus', 'medic-extension' ),
        'bx bx-envelope'            => esc_html__( 'Envelope', 'medic-extension' ),    
        'bx bx-area'                => esc_html__( 'Area', 'medic-extension' ), 
        'bx bxs-widget'             => esc_html__( 'Widget', 'medic-extension' ),
        'bx bx-calendar-event'      => esc_html__( 'Calendar Event', 'medic-extension' ), 
        'bx bx-id-card'             => esc_html__( 'Id Card', 'medic-extension' ), 
        'bx bxs-widget'             => esc_html__( 'Widget', 'medic-extension' ),
        'bx bx-trophy'              => esc_html__( 'Trophy', 'medic-extension' ),
        'bx bx-certification'       => esc_html__( 'Certification', 'medic-extension' ),
        'flaticon-medicine'         => esc_html__( 'Medicine', 'medic-extension' ),
        'flaticon-neurology'        => esc_html__( 'Neurology', 'medic-extension' ),
        'flaticon-eye'              => esc_html__( 'Eye', 'medic-extension' ),
        'flaticon-heart'            => esc_html__( 'Heart', 'medic-extension' ),
        'flaticon-dental-care'      => esc_html__( 'Dental Care', 'medic-extension' ),
        'flaticon-lungs'            => esc_html__( 'Lungs', 'medic-extension' )  
    ];
}

function medic_extension_include_icons() {
    return array_keys(medic_extension_icons() );
}

/**
 * Add custom icon into dpeartment editor
 */
function medic_extension_department_icons() {
    return [
        'flaticon-medicine'         => esc_html__( 'medicine', 'medic-extension' ),
        'flaticon-neurology'        => esc_html__( 'neurology', 'medic-extension' ),
        'flaticon-eye'              => esc_html__( 'eye', 'medic-extension' ),
        'flaticon-heart'            => esc_html__( 'heart', 'medic-extension' ),
        'flaticon-dental-care'      => esc_html__( 'dental-care', 'medic-extension' ),
        'flaticon-lungs'            => esc_html__( 'lungs', 'medic-extension' ),
        'flaticon-brain'            => esc_html__( 'brain', 'medic-extension' ),
        'flaticon-tooth'            => esc_html__( 'tooth', 'medic-extension' ),
        'flaticon-capsules'         => esc_html__( 'capsules', 'medic-extension' ),
        'flaticon-cardiogram'       => esc_html__( 'cardiogram', 'medic-extension' ),
        'flaticon-doctor'           => esc_html__( 'doctor', 'medic-extension' ),
        'flaticon-scissors'         => esc_html__( 'scissors', 'medic-extension' ), 
        'flaticon-conference'       => esc_html__( 'conference', 'medic-extension' ), 
        'flaticon-wheelchair'       => esc_html__( 'wheelchair', 'medic-extension' ), 
        'flaticon-ambulance'        => esc_html__( 'ambulance', 'medic-extension' ),
        'flaticon-first-aid-kit'    => esc_html__( 'first-aid-kit', 'medic-extension' ),
        'flaticon-pills'            => esc_html__( 'pills', 'medic-extension' ),
        'flaticon-paper-plane'      => esc_html__( 'paper-plane', 'medic-extension' ),
        'flaticon-envelope'         => esc_html__( 'envelope', 'medic-extension' ),
        'flaticon-phone'            => esc_html__( 'phone', 'medic-extension' ),
        'flaticon-right'            => esc_html__( 'right', 'medic-extension' ),
        'flaticon-left'             => esc_html__( 'left', 'medic-extension' ),
        'flaticon-user-experience'  => esc_html__( 'user-experience', 'medic-extension' ),
        'flaticon-stethoscope'      => esc_html__( 'stethoscope', 'medic-extension' ),
        'flaticon-heart-rate'       => esc_html__( 'heart-rate', 'medic-extension' )   
    ];
}

add_action('admin_head', 'department_custom_fonts_css');

function department_custom_fonts_css() {
  echo '<style>
    select#custom_element_grid_class_medic_department_icon, #custom_element_grid_class_medic_department_icon option {
      text-transform: capitalize;
    } 
  </style>';
}
