<?php exit; ?>
[2022-09-27 15:06:01] ERROR: Form 35 > Mailchimp API error: 0 cURL error 28: Operation timed out after 10000 milliseconds with 0 out of 0 bytes received.

Request: 
GET https://us7.api.mailchimp.com/3.0/lists/2ab4a2c412/members/760a0b9d792419e31dca268b04121d64
