<?php if (!defined('FW')) die('Forbidden');
/**
 * @var string $uri Demo directory url
 */

$manifest = array();
$manifest['title'] = __('Medic Demo', 'medic');
$manifest['screenshot'] = $uri . '/screenshot.png';
$manifest['preview_link'] = 'https://medic.mhrtheme.com/';
