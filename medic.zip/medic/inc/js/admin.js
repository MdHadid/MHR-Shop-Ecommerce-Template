(function($) {
	'use strict';

    $(".notice.medic-theme-notice.first-notice button.button-secondary").on("click", function(){
	    $(".notice.medic-theme-notice.first-notice").slideUp();
    });

    $(".notice.medic-theme-notice.second-notice button.button-secondary").on("click", function(){
	    $(".notice.medic-theme-notice.second-notice").slideUp();
    });

    $('.notice.medic-theme-notice.first-notice button.button-secondary').click(function() {
        $.cookie('MedicFirstNotice', 'A cookie for MedicFirstNotice', { expires: 180 });
	});

    if ($.cookie('MedicFirstNotice')) {
        $('.notice.medic-theme-notice.first-notice').css('display', 'none');
    }

    $('.notice.medic-theme-notice.second-notice button.button-secondary').click(function() {
        $.cookie('MedicSecondNotice', 'A cookie for MedicSecondNotice', { expires: 180 });
	});

    if ($.cookie('MedicSecondNotice')) {
        $('.notice.medic-theme-notice.second-notice').css('display', 'none');
    }

})(jQuery);
