<?php

/**
 * Enqueue admin scripts and styles.
*/

if( ! function_exists( 'medic_admin_scripts' ) ) :
function medic_admin_scripts(){
    wp_enqueue_style( 'medic-admin', get_template_directory_uri() . '/inc/css/admin.css', '', _S_VERSION );
    wp_enqueue_script( 'medic-jquery-cookie', get_template_directory_uri().'/inc/js/jquery.cookie.js', array( 'jquery' ), _S_VERSION, true );
     wp_enqueue_script( 'medic-admin', get_template_directory_uri().'/inc/js/admin.js', array( 'jquery' ), _S_VERSION, true );
}
endif; 
add_action( 'admin_enqueue_scripts', 'medic_admin_scripts' );

function medic_admin_notice_review() {
    global $pagenow;
    if ( $pagenow == 'index.php' ) { ?>
    <div class="notice medic-theme-notice notice-success second-notice is-dismissible">
        <p class="review"><?php _e( 'Rate a 5-star rating of this theme and get a discount of up to 15% on your next purchase.', 'medic' ); ?>
        </p>
        <p>
        	<a class="button button-primary" href="https://account.templatemonster.com/downloads" target="_blank"><?php _e( 'Review Our Theme', 'medic' ); ?></a>
        	<button class="button button-secondary" target="_blank"><?php _e( "Don't Show Again", 'medic' ); ?></button>
        </p>
    </div>
    <?php  }
} 

if (isset($_COOKIE['MedicSecondNotice'])) {
}
else {
   add_action( 'admin_notices', 'medic_admin_notice_review' );
}
