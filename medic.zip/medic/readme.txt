=== Medic - Hospital, Diagnostic, Clinic, Health and Medical Lab WordPress Theme ===

Contributors: MhrTheme
Tags: hospital, diagnostic, clinic, health, medical, lab, elementor, website, theme, wordpress, woocommerce, doctor, testimonial, appointment, contact, department, services, shop, product, equipment

Tested up to: 6.3.1
Requires PHP: 7.4
Stable tag: 1.1
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Medic is a WordPress theme that is based on the hospital, diagnostic, clinic, health, and medical lab website.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

Medic includes support for WooCommerce, Elementor Website Builder & Contact Form 7.

= 1.0.0 =
* Initial release
